# Masrouf (مصروف) — C++ edition

Track expenses with **one sentence**. Type `30 دج ماء` and it is saved instantly: no forms, no steps.

This repository contains **Phase 1** of the Masrouf spec as a C++17 program:
a tested core library plus a command-line app. It runs fully offline, with no account and no server.

## Build and run

You need a C++17 compiler (g++, clang or MSVC). CMake is optional.

```bash
# Option A: CMake
cmake -S . -B build
cmake --build build
./build/masrouf            # Windows: build\Debug\masrouf.exe

# Option B: one command, no CMake
g++ -std=c++17 -O2 -Icore core/*.cpp cli/main.cpp -o masrouf
./masrouf
```

Run the tests:

```bash
ctest --test-dir build --output-on-failure
# or without CMake:
g++ -std=c++17 -Icore core/*.cpp tests/test_core.cpp -o test_core && ./test_core
```

**Windows terminal:** run `chcp 65001` first so Arabic text is displayed and typed correctly
(Windows Terminal handles it better than the old console).

## Using it

```
> 30 دج ماء                       saves 30 DA, category: food
> 30 ماء و50 خبز و100 طرام         3 entries, one message, one undo
> أمس 200 كراء                    dated yesterday (also: أول أمس, hier, yesterday)
> +5000 bourse                    income (also: استلمت 5000, 5000 مصروف, reçu 5000)
> ماء                             no amount: nothing is saved, you are asked for it
> /undo                           undoes the last action
```

| Command | What it does |
|---|---|
| `/list [n]` | latest entries with their numbers |
| `/summary [day\|week\|month] [offset]` | totals, share per category, budget bar (offset `-1` = previous period) |
| `/edit 5 45 ماء` | change amount / label of entry 5 |
| `/delete 5` | delete entry 5 (undoable) |
| `/cat 5 housing` | correct the category; the app **remembers** it for that word |
| `/budget 15000` or `/budget off` | optional monthly budget, gentle alert at 80% |
| `/lang ar\|fr\|en` | interface language (Arabic by default) |
| `/currency DZD` | DZD (default), EUR, USD, MAD, TND, SAR, EGP |

Data is stored as plain text in `~/.masrouf/` (override with `MASROUF_HOME` or `masrouf --data <folder>`).

## What the parser understands

- Amounts: `30`, `٣٠`, `30دج`, `30 da`, `30 DA`, `12,5`, `1.500`, `1,500`
- Several items in one sentence, amount first (`30 ماء و50 خبز`) or label first (`ماء 30 خبز 50`)
- Arabic, French, Darija and English words mixed (`خبز`, `pain`, `طرام`)
- Categories: food & drinks, transport, study & books, phone & internet, entertainment, housing, other.
  Unknown words are saved as *other* immediately and never block you.

## Layout

```
core/    parser, categories, storage, summaries, texts (no UI, no network, fully tested)
cli/     the command-line app
tests/   dependency-free tests (141 checks)
docs/    notes for the phone version and Phase 2
```

## Status

| Spec item | State |
|---|---|
| Sentence parser, categories, learning from corrections | done, tested |
| Local storage, works offline, no account | done, tested |
| Summary day / week / month, optional budget with 80% alert | done |
| Arabic (default) / French / English, currency DZD | done |
| Phone UI (single text box, toast with Undo button, swipe lists, purple theme) | **not in this repo**, see `docs/PHONE_APP.md` |
| Phase 2 (voice, receipt photo, reminders, export, app lock) | not started, see `docs/PHONE_APP.md` |
