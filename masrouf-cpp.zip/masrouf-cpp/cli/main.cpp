// Masrouf - command-line front end.
// Type one sentence ("30 دج ماء") and the expense is saved instantly.
#include <algorithm>
#include <cctype>
#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include <string>
#include <vector>

#include "categories.hpp"
#include "i18n.hpp"
#include "parser.hpp"
#include "store.hpp"
#include "summary.hpp"
#include "text.hpp"

using namespace masrouf;

namespace {

struct UndoAction {
  enum Kind { None, Inserted, Deleted, Edited } kind = None;
  std::vector<int> ids;  // Inserted
  Entry entry;           // Deleted / Edited: the entry as it was before
};

struct App {
  Store store;
  Lang lang = Lang::Ar;
  std::string currency = "DZD";
  UndoAction undo;

  explicit App(const std::string& dir) : store(dir) {}

  const Tr& t() const { return tr(lang); }
  std::string cur() const { return currencySymbol(currency, lang); }
  std::string money(double v) const { return formatAmount(v) + " " + cur(); }
  double budget() const { return std::atof(store.get("budget", "0").c_str()); }

  std::string labelOrDefault(const Entry& e) const {
    if (!e.label.empty()) return e.label;
    return e.income ? t().default_income : t().default_expense;
  }
};

std::string trim(const std::string& s) {
  size_t b = 0, e = s.size();
  while (b < e && (s[b] == ' ' || s[b] == '\t' || s[b] == '\r' || s[b] == '\n')) ++b;
  while (e > b && (s[e - 1] == ' ' || s[e - 1] == '\t' || s[e - 1] == '\r' || s[e - 1] == '\n')) --e;
  return s.substr(b, e - b);
}

std::string dateText(std::time_t t, bool withTime) {
  std::tm tm{};
#ifdef _WIN32
  localtime_s(&tm, &t);
#else
  localtime_r(&t, &tm);
#endif
  char buf[32];
  std::strftime(buf, sizeof buf, withTime ? "%Y-%m-%d %H:%M" : "%Y-%m-%d", &tm);
  return buf;
}

std::string bar(double fraction, int width = 20) {
  if (fraction < 0) fraction = 0;
  if (fraction > 1) fraction = 1;
  const int filled = static_cast<int>(fraction * width + 0.5);
  std::string s;
  for (int i = 0; i < width; ++i) s += i < filled ? "█" : "░";
  return s;
}

void printBudgetLine(const App& app, double spent) {
  const double budget = app.budget();
  if (budget <= 0) return;  // no budget: nothing is shown
  if (spent > budget) {
    std::cout << fill(app.t().budget_over, {{"over", formatAmount(spent - budget)},
                                            {"spent", formatAmount(spent)},
                                            {"budget", formatAmount(budget)}});
  } else {
    std::cout << fill(app.t().budget_line, {{"spent", formatAmount(spent)},
                                            {"budget", formatAmount(budget)},
                                            {"left", formatAmount(budget - spent)}});
  }
  std::cout << "  " << bar(spent / budget) << " " << static_cast<int>(spent * 100 / budget) << "%\n";
}

// ---------------------------------------------------------------- commands

void saveSentence(App& app, const std::string& line) {
  const std::time_t now = std::time(nullptr);
  const ParseResult r = parseSentence(line, now);
  if (r.entries.empty()) {  // nothing saved, the sentence stays visible above
    std::cout << app.t().need_amount << "\n";
    return;
  }

  std::vector<Entry> fresh;
  for (const ParsedEntry& p : r.entries) {
    Entry e;
    e.income = p.income;
    e.amount = p.amount;
    e.when = p.when;
    e.label = p.label;
    e.category = p.income ? Category::Income : categorize(p.label, app.store.learned());
    fresh.push_back(e);
  }

  const double before = monthExpenses(app.store.entries(), now);
  const std::vector<Entry> added = app.store.add(fresh);

  // One toast, one undo for the whole sentence.
  if (added.size() == 1) {
    const Entry& e = added[0];
    const char* templ = e.income ? app.t().saved_income : app.t().saved_one;
    std::cout << "✔ " << fill(templ, {{"amount", formatAmount(e.amount)}, {"cur", app.cur()},
                                      {"label", app.labelOrDefault(e)}})
              << "   [#" << e.id << "]\n";
  } else {
    std::cout << "✔ " << fill(app.t().saved_many, {{"n", std::to_string(added.size())}}) << "\n";
    for (const Entry& e : added) {
      std::cout << "   " << (e.income ? "+" : "") << formatAmount(e.amount) << " " << app.cur()
                << " - " << app.labelOrDefault(e) << "   [#" << e.id << "]\n";
    }
  }
  std::cout << "   " << app.t().undo_hint << "\n";

  app.undo = UndoAction();
  app.undo.kind = UndoAction::Inserted;
  for (const Entry& e : added) app.undo.ids.push_back(e.id);

  // Gentle alert when this sentence takes the month past 80% of the budget.
  const double budget = app.budget();
  if (budget > 0) {
    const double after = monthExpenses(app.store.entries(), now);
    if (before / budget < 0.8 && after / budget >= 0.8) {
      std::cout << "⚠ " << fill(app.t().budget_alert, {{"pct", std::to_string(static_cast<int>(after * 100 / budget))}})
                << "\n";
    }
  }
}

void cmdList(App& app, const std::string& arg) {
  int n = 10;
  if (!arg.empty()) n = std::max(1, std::atoi(arg.c_str()));
  const auto& all = app.store.entries();
  if (all.empty()) {
    std::cout << app.t().empty_list << "\n";
    return;
  }
  const int start = std::max(0, static_cast<int>(all.size()) - n);
  for (int i = static_cast<int>(all.size()) - 1; i >= start; --i) {
    const Entry& e = all[i];
    std::cout << "#" << e.id << "  " << dateText(e.when, true) << "  " << (e.income ? "+" : "")
              << app.money(e.amount) << "  " << app.labelOrDefault(e) << "  ["
              << categoryName(e.category, app.lang) << "]\n";
  }
}

void cmdSummary(App& app, const std::string& arg) {
  Period period = Period::Day;
  int offset = 0;
  const std::vector<std::string> parts = splitSpaces(arg);
  if (!parts.empty()) {
    const std::string p = fold(parts[0]);
    if (p == "week" || p == "semaine" || p == "اسبوع" || p == "الاسبوع") period = Period::Week;
    else if (p == "month" || p == "mois" || p == "شهر" || p == "الشهر") period = Period::Month;
    else if (p == "day" || p == "jour" || p == "يوم" || p == "اليوم") period = Period::Day;
    else offset = std::atoi(parts[0].c_str());
  }
  if (parts.size() > 1) offset = std::atoi(parts[1].c_str());

  const std::time_t now = std::time(nullptr);
  const Range range = rangeFor(period, now, offset);
  const Summary s = summarize(app.store.entries(), range);

  const char* name = period == Period::Day ? app.t().period_day
                     : period == Period::Week ? app.t().period_week : app.t().period_month;
  std::cout << "== " << name << ": " << dateText(range.begin, false) << " → "
            << dateText(range.end - 1, false) << " ==\n";
  if (s.count == 0) {
    std::cout << app.t().empty_period << "\n";
  } else {
    std::cout << app.t().total_expenses << ": " << app.money(s.expenses) << "\n";
    std::cout << app.t().total_income << ": " << app.money(s.income) << "\n";
    std::cout << app.t().balance << ": " << app.money(s.income - s.expenses) << "\n\n";
    for (const CategoryTotal& c : s.byCategory) {
      std::cout << "  " << bar(c.percent / 100.0, 10) << " " << categoryName(c.category, app.lang)
                << "  " << app.money(c.total) << "  " << static_cast<int>(c.percent + 0.5) << "%\n";
    }
  }
  if (period == Period::Month) {
    std::cout << "\n";
    printBudgetLine(app, s.expenses);
    const double budget = app.budget();
    if (budget > 0 && s.expenses / budget >= 0.8 && offset == 0) {
      std::cout << "⚠ " << fill(app.t().budget_alert, {{"pct", std::to_string(static_cast<int>(s.expenses * 100 / budget))}})
                << "\n";
    }
  }
}

void cmdUndo(App& app) {
  UndoAction& u = app.undo;
  switch (u.kind) {
    case UndoAction::None:
      std::cout << app.t().nothing_to_undo << "\n";
      return;
    case UndoAction::Inserted:
      for (int id : u.ids) app.store.remove(id);
      break;
    case UndoAction::Deleted: {
      Entry restored = u.entry;
      app.store.add({restored});
      break;
    }
    case UndoAction::Edited:
      app.store.update(u.entry);
      break;
  }
  u = UndoAction();
  std::cout << app.t().undone << "\n";
}

void cmdDelete(App& app, const std::string& arg) {
  const int id = std::atoi(arg.c_str());
  Entry removed;
  if (id <= 0 || !app.store.remove(id, &removed)) {
    std::cout << fill(app.t().not_found, {{"id", arg}}) << "\n";
    return;
  }
  app.undo = UndoAction();
  app.undo.kind = UndoAction::Deleted;
  app.undo.entry = removed;
  std::cout << fill(app.t().deleted, {{"id", std::to_string(id)}}) << "   " << app.t().undo_hint << "\n";
}

void cmdEdit(App& app, const std::string& arg) {
  const std::vector<std::string> parts = splitSpaces(arg);
  if (parts.size() < 2) {
    std::cout << app.t().usage_edit << "\n";
    return;
  }
  const int id = std::atoi(parts[0].c_str());
  const Entry* cur = id > 0 ? app.store.find(id) : nullptr;
  if (!cur) {
    std::cout << fill(app.t().not_found, {{"id", parts[0]}}) << "\n";
    return;
  }
  std::string text = trim(arg.substr(arg.find(parts[0]) + parts[0].size()));
  const ParseResult r = parseSentence(text, std::time(nullptr));
  if (r.entries.empty()) {
    std::cout << app.t().need_amount << "\n";
    return;
  }
  const Entry before = *cur;
  Entry e = before;
  e.amount = r.entries[0].amount;
  e.label = r.entries[0].label;
  e.income = r.entries[0].income;
  if (r.dateGiven) e.when = r.entries[0].when;  // keep the original date unless a new one is typed
  e.category = e.income ? Category::Income : categorize(e.label, app.store.learned());
  app.store.update(e);
  app.undo = UndoAction();
  app.undo.kind = UndoAction::Edited;
  app.undo.entry = before;
  std::cout << fill(app.t().updated, {{"id", std::to_string(id)}}) << "   " << app.t().undo_hint << "\n";
}

void cmdCategory(App& app, const std::string& arg) {
  const std::vector<std::string> parts = splitSpaces(arg);
  if (parts.size() < 2) {
    std::cout << app.t().usage_cat << "\n";
    return;
  }
  const int id = std::atoi(parts[0].c_str());
  const Entry* cur = id > 0 ? app.store.find(id) : nullptr;
  if (!cur) {
    std::cout << fill(app.t().not_found, {{"id", parts[0]}}) << "\n";
    return;
  }
  Category c;
  const std::string wanted = trim(arg.substr(arg.find(parts[0]) + parts[0].size()));
  if (!categoryFromText(wanted, &c) || c == Category::Income) {
    std::cout << app.t().category_unknown << "\n";
    return;
  }
  Entry e = *cur;
  e.category = c;
  app.store.update(e);
  app.store.learn(e.label, c);  // the app remembers the correction
  std::cout << fill(app.t().category_set, {{"id", std::to_string(id)}, {"cat", categoryName(c, app.lang)}}) << "\n";
}

void cmdBudget(App& app, const std::string& arg) {
  const std::string a = fold(arg);
  if (a == "off" || a == "0" || a == "none") {
    app.store.set("budget", "0");
    std::cout << app.t().budget_off << "\n";
    return;
  }
  const double v = std::atof(arg.c_str());
  if (v <= 0) {
    std::cout << app.t().usage_budget << "\n";
    return;
  }
  char num[40];
  std::snprintf(num, sizeof num, "%.2f", v);
  app.store.set("budget", num);
  std::cout << fill(app.t().budget_set, {{"budget", app.money(v)}}) << "\n";
}

void runCommand(App& app, const std::string& line, bool* quit) {
  const size_t space = line.find(' ');
  const std::string cmd = fold(line.substr(1, space == std::string::npos ? std::string::npos : space - 1));
  const std::string arg = space == std::string::npos ? "" : trim(line.substr(space + 1));

  if (cmd == "help" || cmd == "h" || cmd == "?") std::cout << app.t().help << "\n";
  else if (cmd == "list" || cmd == "ls") cmdList(app, arg);
  else if (cmd == "summary" || cmd == "s") cmdSummary(app, arg);
  else if (cmd == "undo" || cmd == "u") cmdUndo(app);
  else if (cmd == "delete" || cmd == "del") cmdDelete(app, arg);
  else if (cmd == "edit") cmdEdit(app, arg);
  else if (cmd == "cat") cmdCategory(app, arg);
  else if (cmd == "budget") cmdBudget(app, arg);
  else if (cmd == "lang") {
    Lang l;
    if (langFromCode(fold(arg), &l)) {
      app.lang = l;
      app.store.set("lang", langCode(l));
      std::cout << app.t().lang_set << "\n";
    } else {
      std::cout << "ar | fr | en\n";
    }
  } else if (cmd == "currency") {
    std::string code;
    for (char c : arg) code.push_back(static_cast<char>(std::toupper(static_cast<unsigned char>(c))));
    if (isKnownCurrency(code)) {
      app.currency = code;
      app.store.set("currency", code);
      std::cout << fill(app.t().currency_set, {{"cur", app.cur()}}) << "\n";
    } else {
      std::cout << app.t().currency_unknown << "\n";
    }
  } else if (cmd == "quit" || cmd == "exit" || cmd == "q") {
    *quit = true;
  } else {
    std::cout << app.t().unknown_command << "\n";
  }
}

}  // namespace

int main(int argc, char** argv) {
  std::ios::sync_with_stdio(false);

  // Optional: masrouf --data /path/to/folder
  std::string dir = Store::defaultDir();
  for (int i = 1; i + 1 < argc; ++i) {
    if (std::string(argv[i]) == "--data") dir = argv[i + 1];
  }

  App app(dir);
  if (!app.store.load()) {
    std::cerr << app.t().data_error << ": " << dir << "\n";
    return 1;
  }
  langFromCode(app.store.get("lang", "ar"), &app.lang);
  const std::string savedCurrency = app.store.get("currency", "DZD");
  if (isKnownCurrency(savedCurrency)) app.currency = savedCurrency;

  std::cout << app.t().welcome << "\n" << app.t().prompt_hint << "\n";

  bool quit = false;
  std::string line;
  while (!quit) {
    std::cout << "> " << std::flush;
    if (!std::getline(std::cin, line)) break;
    line = trim(line);
    if (line.empty()) continue;
    if (line[0] == '/') runCommand(app, line, &quit);
    else saveSentence(app, line);
  }
  std::cout << app.t().bye << "\n";
  return 0;
}
