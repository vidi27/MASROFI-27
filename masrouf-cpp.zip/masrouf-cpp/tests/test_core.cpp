// Dependency-free tests for the Masrouf core: parser, categorizer, storage, summary.
#include <cstdio>
#include <cstdlib>
#include <filesystem>
#include <string>

#include "categories.hpp"
#include "i18n.hpp"
#include "parser.hpp"
#include "store.hpp"
#include "summary.hpp"

using namespace masrouf;

static int failures = 0;
static int checks = 0;

#define CHECK(cond)                                                          \
  do {                                                                       \
    ++checks;                                                                \
    if (!(cond)) {                                                           \
      ++failures;                                                            \
      std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);            \
    }                                                                        \
  } while (0)

static const std::time_t kNow = 1790000000;  // any fixed instant

static ParseResult P(const std::string& s) { return parseSentence(s, kNow); }

static void testSingleExpense() {
  for (const char* s : {"30 دج ماء", "٣٠ ماء", "30دج ماء", "30 da ماء", "30 DA ماء", "ماء 30 دج",
                        "30 د.ج ماء"}) {
    ParseResult r = P(s);
    CHECK(r.error == ParseError::None);
    CHECK(r.entries.size() == 1);
    if (r.entries.size() == 1) {
      CHECK(r.entries[0].amount == 30);
      CHECK(r.entries[0].label == "ماء");
      CHECK(!r.entries[0].income);
      CHECK(r.entries[0].when == kNow);
    }
  }
}

static void testMultipleItems() {
  ParseResult r = P("30 ماء و50 خبز و100 طرام");
  CHECK(r.entries.size() == 3);
  if (r.entries.size() == 3) {
    CHECK(r.entries[0].amount == 30 && r.entries[0].label == "ماء");
    CHECK(r.entries[1].amount == 50 && r.entries[1].label == "خبز");
    CHECK(r.entries[2].amount == 100 && r.entries[2].label == "طرام");
  }
  r = P("30 pain et 50 lait");
  CHECK(r.entries.size() == 2);
  if (r.entries.size() == 2) CHECK(r.entries[0].label == "pain" && r.entries[1].label == "lait");

  r = P("ماء 30 خبز 50");  // label first
  CHECK(r.entries.size() == 2);
  if (r.entries.size() == 2) {
    CHECK(r.entries[0].amount == 30 && r.entries[0].label == "ماء");
    CHECK(r.entries[1].amount == 50 && r.entries[1].label == "خبز");
  }
  r = P("30 ماء، 50 خبز");
  CHECK(r.entries.size() == 2);
}

static void testLabelsWithSeveralWords() {
  ParseResult r = P("عصير حليب 120");
  CHECK(r.entries.size() == 1);
  if (!r.entries.empty()) CHECK(r.entries[0].label == "عصير حليب" && r.entries[0].amount == 120);
  r = P("120 عصير و حليب");
  CHECK(r.entries.size() == 1);
  if (!r.entries.empty()) CHECK(r.entries[0].label == "عصير و حليب");
}

static void testDates() {
  ParseResult r = P("أمس 200 كراء");
  CHECK(r.entries.size() == 1 && r.dateGiven);
  if (!r.entries.empty()) {
    CHECK(r.entries[0].when == kNow - 86400);
    CHECK(r.entries[0].label == "كراء");
  }
  r = P("200 كراء امس");
  CHECK(!r.entries.empty() && r.entries[0].when == kNow - 86400);
  r = P("أول أمس 40 pain");
  CHECK(!r.entries.empty() && r.entries[0].when == kNow - 2 * 86400 && r.entries[0].label == "pain");
  r = P("avant-hier 40 pain");
  CHECK(!r.entries.empty() && r.entries[0].when == kNow - 2 * 86400);
  r = P("hier 15 café");
  CHECK(!r.entries.empty() && r.entries[0].when == kNow - 86400);
  r = P("30 ماء اليوم");
  CHECK(!r.entries.empty() && r.entries[0].when == kNow && r.dateGiven);
}

static void testIncome() {
  ParseResult r = P("+5000 bourse");
  CHECK(r.entries.size() == 1 && r.entries[0].income && r.entries[0].amount == 5000);
  CHECK(r.entries[0].label == "bourse");
  r = P("استلمت 5000");
  CHECK(r.entries.size() == 1 && r.entries[0].income && r.entries[0].label.empty());
  r = P("5000 مصروف");
  CHECK(r.entries.size() == 1 && r.entries[0].income);
  r = P("+ 200 من أمي");
  CHECK(r.entries.size() == 1 && r.entries[0].income && r.entries[0].amount == 200);
  r = P("+5000 bourse و30 خبز");
  CHECK(r.entries.size() == 2 && r.entries[0].income && !r.entries[1].income);
}

static void testNoAmount() {
  for (const char* s : {"ماء", "", "   ", "خبز وحليب", "0 ماء"}) {
    ParseResult r = P(s);
    CHECK(r.error == ParseError::NoAmount);
    CHECK(r.entries.empty());
  }
}

static void testNumberFormats() {
  ParseResult r = P("1.500 كراء");
  CHECK(!r.entries.empty() && r.entries[0].amount == 1500);
  r = P("1,500 loyer");
  CHECK(!r.entries.empty() && r.entries[0].amount == 1500);
  r = P("12,5 pain");
  CHECK(!r.entries.empty() && r.entries[0].amount == 12.5);
  r = P("12.5 pain");
  CHECK(!r.entries.empty() && r.entries[0].amount == 12.5);
  r = P("١٢٥٠ كراء");
  CHECK(!r.entries.empty() && r.entries[0].amount == 1250);
  r = P("30");
  CHECK(r.entries.size() == 1 && r.entries[0].amount == 30 && r.entries[0].label.empty());
}

static void testCategories() {
  LearnedMap none;
  struct Case { const char* label; Category expected; };
  const Case cases[] = {
      {"ماء", Category::Food},          {"الماء", Category::Food},
      {"خبز", Category::Food},          {"pain", Category::Food},
      {"Café", Category::Food},         {"أكل", Category::Food},
      {"طرام", Category::Transport},    {"taxi", Category::Transport},
      {"كراء", Category::Housing},      {"loyer", Category::Housing},
      {"internet", Category::Telecom},  {"فاتورة الانترنت", Category::Telecom},
      {"flexy", Category::Telecom},     {"كتاب", Category::Study},
      {"livre", Category::Study},       {"سينما", Category::Entertainment},
      {"فاتورة الماء", Category::Housing}, {"facture d'eau", Category::Housing},
      {"facture", Category::Housing},   {"xyz", Category::Other},
      {"", Category::Other},            {"حاجة", Category::Other},
  };
  for (const Case& c : cases) {
    const Category got = categorize(c.label, none);
    if (got != c.expected) std::printf("  categorize(\"%s\") = %s, expected %s\n", c.label,
                                       categoryId(got), categoryId(c.expected));
    CHECK(got == c.expected);
  }
  // A remembered correction always wins, even through "ال" and spelling variants.
  LearnedMap learned;
  learned[normalizeLabel("كراء")] = Category::Other;
  CHECK(categorize("الكراء", learned) == Category::Other);
  CHECK(categorize("كراء", learned) == Category::Other);
  learned[normalizeLabel("حاجة")] = Category::Food;
  CHECK(categorize("حاجة", learned) == Category::Food);
}

static void testStoreAndSummary() {
  namespace fs = std::filesystem;
  const fs::path dir = fs::temp_directory_path() / "masrouf_test_store";
  fs::remove_all(dir);

  {
    Store s(dir.string());
    CHECK(s.load());
    Entry a; a.amount = 30; a.when = kNow; a.category = Category::Food; a.label = "ماء\twith tab";
    Entry b; b.amount = 100; b.when = kNow; b.category = Category::Transport; b.label = "طرام";
    Entry c; c.income = true; c.amount = 5000; c.when = kNow; c.category = Category::Income; c.label = "bourse";
    auto added = s.add({a, b, c});
    CHECK(added.size() == 3 && added[0].id == 1 && added[2].id == 3);
    s.set("budget", "15000");
    s.learn("كراء", Category::Housing);
    Entry removed;
    CHECK(s.remove(2, &removed) && removed.label == "طرام");
    CHECK(!s.remove(99));
  }
  {
    Store s(dir.string());  // reload from disk
    CHECK(s.load());
    CHECK(s.entries().size() == 2);
    CHECK(s.find(1) && s.find(1)->label == "ماء\twith tab");
    CHECK(s.get("budget") == "15000");
    CHECK(s.learned().count(normalizeLabel("كراء")) == 1);
    auto more = s.add({Entry()});
    CHECK(more.size() == 1 && more[0].id == 4);  // ids never reused

    const Range day = rangeFor(Period::Day, kNow, 0);
    CHECK(day.begin <= kNow && kNow < day.end);
    const Summary sum = summarize(s.entries(), day);
    CHECK(sum.expenses == 30 && sum.income == 5000);
    CHECK(sum.byCategory.size() >= 1 && sum.byCategory[0].category == Category::Food);
    CHECK(sum.byCategory[0].percent > 99.9);
    CHECK(summarize(s.entries(), rangeFor(Period::Day, kNow, -1)).count == 0);

    const Range week = rangeFor(Period::Week, kNow, 0);
    CHECK(week.end - week.begin >= 7 * 86400 - 3600 && week.end - week.begin <= 7 * 86400 + 3600);
    const Range month = rangeFor(Period::Month, kNow, 0);
    CHECK(month.begin <= kNow && kNow < month.end);
    CHECK(monthExpenses(s.entries(), kNow) == 30);
  }
  fs::remove_all(dir);
}

static void testI18n() {
  CHECK(formatAmount(1500) == "1 500");
  CHECK(formatAmount(1234567) == "1 234 567");
  CHECK(formatAmount(12.5) == "12.5");
  CHECK(formatAmount(30) == "30");
  CHECK(fill("{a}-{b}", {{"a", "x"}, {"b", "y"}}) == "x-y");
  Category c;
  CHECK(categoryFromText("food", &c) && c == Category::Food);
  CHECK(categoryFromText("سكن", &c) && c == Category::Housing);
  CHECK(categoryFromText("Logement", &c) && c == Category::Housing);
  CHECK(!categoryFromText("nope", &c));
  Lang l;
  CHECK(langFromCode("fr", &l) && l == Lang::Fr);
  CHECK(!langFromCode("de", &l));
  CHECK(currencySymbol("DZD", Lang::Ar) == "دج" && currencySymbol("DZD", Lang::En) == "DA");
}

int main() {
  testSingleExpense();
  testMultipleItems();
  testLabelsWithSeveralWords();
  testDates();
  testIncome();
  testNoAmount();
  testNumberFormats();
  testCategories();
  testStoreAndSummary();
  testI18n();
  std::printf("%d checks, %d failures\n", checks, failures);
  return failures == 0 ? 0 : 1;
}
