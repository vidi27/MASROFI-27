# From this core to the phone app

C++ is not used to draw Android screens by itself. The usual route for a C++ app on a phone is **Qt (Qt Quick / QML)**,
which builds the same C++ code for Android and iOS. The `core/` folder was written for exactly that:

- It has **no UI and no platform-specific code** (only the standard library; storage uses `std::filesystem`).
- The whole interface is plain function calls, so a screen can call them directly:
  - `parseSentence(text, now)` → entries (amount, label, income, date)
  - `categorize(label, store.learned())`
  - `store.add(...)`, `store.remove(...)`, `store.update(...)`, `store.learn(...)`
  - `summarize(entries, rangeFor(Period::Month, now, 0))`

## What a Qt front end has to add (Phase 1 screens)

1. **Home**: one `TextField` focused on start; on Enter call `parseSentence` then `store.add`; show a toast with an **Undo** button for a few seconds.
2. **Summary**: Day / Week / Month switch, big total, donut chart by category, swipeable list.
3. **Settings**: language, currency, monthly budget.
4. **Look**: purple background on every screen (vivid purple in light mode, deeper purple in dark mode, light text).
5. **RTL**: Arabic by default (`LayoutMirroring.enabled: true` in QML).

Point the store at the app's private data folder (`QStandardPaths::AppDataLocation`) instead of `~/.masrouf`.

## Phase 2 hooks

- **Voice / camera**: both produce text. Voice text goes through the same `parseSentence`. A receipt photo yields a total (OCR) and is
  saved as an entry with a "pending review" status when the details are not understood.
  To prepare for that, add two fields to `Entry` (`status`, `photoPath`) and one column to `entries.tsv`.
- **Daily quota for AI features, reminders, recurring expenses, export, app lock**: all live in the front end;
  `Store` already has `get/set` for settings.
- **Cloud backup (optional account)**: copy the three `.tsv` files; no schema change needed.
