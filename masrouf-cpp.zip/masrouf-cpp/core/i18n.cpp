#include "i18n.hpp"

#include <cmath>
#include <cstdio>

#include "text.hpp"

namespace masrouf {

bool langFromCode(const std::string& code, Lang* out) {
  Lang l;
  if (code == "ar") l = Lang::Ar;
  else if (code == "fr") l = Lang::Fr;
  else if (code == "en") l = Lang::En;
  else return false;
  if (out) *out = l;
  return true;
}

const char* langCode(Lang l) { return l == Lang::Ar ? "ar" : l == Lang::Fr ? "fr" : "en"; }
bool isRtl(Lang l) { return l == Lang::Ar; }

namespace {

const Tr kAr = {
    "مصروف - سجّل مصروفاتك بجملة واحدة",
    "اكتب مصروفك، مثال: 30 دج ماء   (اكتب /help للمساعدة)",
    "تم حفظ {amount} {cur} - {label}",
    "تم تسجيل دخل {amount} {cur} - {label}",
    "تم حفظ {n} عمليات:",
    "للتراجع اكتب /undo",
    "اكتب المبلغ أيضاً، مثال: 30 دج ماء",
    "تم التراجع",
    "لا يوجد ما يُتراجع عنه",
    "تم حذف العملية {id}",
    "تم تعديل العملية {id}",
    "لا توجد عملية بالرقم {id}",
    "تنبيه: استهلكت {pct}% من ميزانية هذا الشهر",
    "صرفت {spent} من {budget} - بقي {left}",
    "تجاوزت الميزانية الشهرية بمقدار {over}  (صرفت {spent} من {budget})",
    "تم تحديد الميزانية الشهرية: {budget}",
    "تم إلغاء الميزانية الشهرية",
    "تم تغيير اللغة إلى العربية",
    "تم تغيير العملة إلى {cur}",
    "عملة غير معروفة. المتاح: DZD EUR USD MAD TND SAR EGP",
    "تم تغيير فئة العملية {id} إلى {cat}",
    "فئة غير معروفة. المتاح: food transport study telecom entertainment housing other",
    "مصروف",
    "دخل",
    "لا توجد عمليات بعد. اكتب أول مصروف لك.",
    "لا توجد عمليات في هذه الفترة.",
    "المصروفات",
    "الدخل",
    "الرصيد",
    "اليوم",
    "الأسبوع",
    "الشهر",
    "أمر غير معروف. اكتب /help",
    "الأوامر:\n"
    "  30 دج ماء             تسجيل مصروف (يمكن عدة مصروفات: 30 ماء و50 خبز)\n"
    "  أمس 200 كراء          تسجيل بتاريخ أمس أو أول أمس\n"
    "  +5000 bourse          تسجيل دخل (أو: استلمت 5000)\n"
    "  /list [عدد]           آخر العمليات\n"
    "  /summary [day|week|month] [إزاحة]   الملخص (إزاحة -1 = الفترة السابقة)\n"
    "  /undo                 التراجع عن آخر عملية\n"
    "  /edit رقم نص          تعديل (مثال: /edit 5 45 ماء)\n"
    "  /delete رقم           حذف\n"
    "  /cat رقم فئة          تغيير الفئة (food transport study telecom entertainment housing other)\n"
    "  /budget مبلغ | off    الميزانية الشهرية\n"
    "  /lang ar|fr|en        اللغة\n"
    "  /currency DZD         العملة\n"
    "  /quit                 خروج",
    "الاستعمال: /edit رقم نص   مثال: /edit 5 45 ماء",
    "الاستعمال: /cat رقم فئة   مثال: /cat 5 food",
    "الاستعمال: /budget 15000   أو   /budget off",
    "تعذّر فتح مجلد البيانات",
    "إلى اللقاء",
};

const Tr kFr = {
    "Masrouf - notez vos dépenses en une phrase",
    "Tapez votre dépense, ex. : 30 DA eau   (tapez /help pour l'aide)",
    "Enregistré : {amount} {cur} - {label}",
    "Revenu enregistré : {amount} {cur} - {label}",
    "{n} opérations enregistrées :",
    "Pour annuler, tapez /undo",
    "Indiquez aussi le montant, ex. : 30 DA eau",
    "Annulé",
    "Rien à annuler",
    "Opération {id} supprimée",
    "Opération {id} modifiée",
    "Aucune opération numéro {id}",
    "Attention : vous avez utilisé {pct} % du budget de ce mois",
    "Dépensé {spent} sur {budget} - reste {left}",
    "Budget mensuel dépassé de {over}  (dépensé {spent} sur {budget})",
    "Budget mensuel défini : {budget}",
    "Budget mensuel supprimé",
    "Langue changée en français",
    "Devise changée en {cur}",
    "Devise inconnue. Disponibles : DZD EUR USD MAD TND SAR EGP",
    "Catégorie de l'opération {id} changée en {cat}",
    "Catégorie inconnue. Disponibles : food transport study telecom entertainment housing other",
    "Dépense",
    "Revenu",
    "Aucune opération pour l'instant. Tapez votre première dépense.",
    "Aucune opération sur cette période.",
    "Dépenses",
    "Revenus",
    "Solde",
    "Jour",
    "Semaine",
    "Mois",
    "Commande inconnue. Tapez /help",
    "Commandes :\n"
    "  30 DA pain             enregistrer une dépense (plusieurs : 30 eau et 50 pain)\n"
    "  hier 200 loyer         enregistrer hier ou avant-hier\n"
    "  +5000 bourse           enregistrer un revenu (ou : reçu 5000)\n"
    "  /list [n]              dernières opérations\n"
    "  /summary [day|week|month] [décalage]   résumé (-1 = période précédente)\n"
    "  /undo                  annuler la dernière action\n"
    "  /edit n texte          modifier (ex. : /edit 5 45 eau)\n"
    "  /delete n              supprimer\n"
    "  /cat n catégorie       changer la catégorie (food transport study telecom entertainment housing other)\n"
    "  /budget montant | off  budget mensuel\n"
    "  /lang ar|fr|en         langue\n"
    "  /currency DZD          devise\n"
    "  /quit                  quitter",
    "Usage : /edit n texte   ex. : /edit 5 45 eau",
    "Usage : /cat n catégorie   ex. : /cat 5 food",
    "Usage : /budget 15000   ou   /budget off",
    "Impossible d'ouvrir le dossier de données",
    "À bientôt",
};

const Tr kEn = {
    "Masrouf - track expenses with one sentence",
    "Type your expense, e.g. 30 DA water   (type /help for help)",
    "Saved {amount} {cur} - {label}",
    "Income saved: {amount} {cur} - {label}",
    "{n} entries saved:",
    "To undo, type /undo",
    "Add the amount too, e.g. 30 DA water",
    "Undone",
    "Nothing to undo",
    "Entry {id} deleted",
    "Entry {id} updated",
    "No entry with number {id}",
    "Heads up: you have used {pct}% of this month's budget",
    "Spent {spent} of {budget} - {left} left",
    "Over the monthly budget by {over}  (spent {spent} of {budget})",
    "Monthly budget set: {budget}",
    "Monthly budget removed",
    "Language changed to English",
    "Currency changed to {cur}",
    "Unknown currency. Available: DZD EUR USD MAD TND SAR EGP",
    "Entry {id} moved to {cat}",
    "Unknown category. Available: food transport study telecom entertainment housing other",
    "Expense",
    "Income",
    "No entries yet. Type your first expense.",
    "No entries in this period.",
    "Expenses",
    "Income",
    "Balance",
    "Day",
    "Week",
    "Month",
    "Unknown command. Type /help",
    "Commands:\n"
    "  30 DA bread            save an expense (several: 30 water and 50 bread)\n"
    "  yesterday 200 rent     save for yesterday or the day before\n"
    "  +5000 bourse           save income (or: received 5000)\n"
    "  /list [n]              latest entries\n"
    "  /summary [day|week|month] [offset]   summary (-1 = previous period)\n"
    "  /undo                  undo the last action\n"
    "  /edit n text           edit (e.g. /edit 5 45 water)\n"
    "  /delete n              delete\n"
    "  /cat n category        change category (food transport study telecom entertainment housing other)\n"
    "  /budget amount | off   monthly budget\n"
    "  /lang ar|fr|en         language\n"
    "  /currency DZD          currency\n"
    "  /quit                  quit",
    "Usage: /edit n text   e.g. /edit 5 45 water",
    "Usage: /cat n category   e.g. /cat 5 food",
    "Usage: /budget 15000   or   /budget off",
    "Cannot open the data folder",
    "Bye",
};

struct CatNames { const char* ar; const char* fr; const char* en; };
const CatNames kCats[] = {
    {"طعام ومشروبات", "Alimentation", "Food & drinks"},
    {"مواصلات", "Transport", "Transport"},
    {"دراسة وكتب", "Études et livres", "Study & books"},
    {"اتصالات وإنترنت", "Téléphone et internet", "Phone & internet"},
    {"ترفيه", "Loisirs", "Entertainment"},
    {"سكن", "Logement", "Housing"},
    {"أخرى", "Autre", "Other"},
    {"دخل", "Revenu", "Income"},
};

struct Currency { const char* code; const char* ar; const char* latin; };
const Currency kCurrencies[] = {
    {"DZD", "دج", "DA"},  {"EUR", "€", "EUR"},    {"USD", "$", "USD"},   {"MAD", "د.م", "MAD"},
    {"TND", "د.ت", "TND"}, {"SAR", "ر.س", "SAR"}, {"EGP", "ج.م", "EGP"},
};

}  // namespace

const Tr& tr(Lang l) { return l == Lang::Ar ? kAr : l == Lang::Fr ? kFr : kEn; }

std::string categoryName(Category c, Lang l) {
  const CatNames& n = kCats[static_cast<int>(c)];
  return l == Lang::Ar ? n.ar : l == Lang::Fr ? n.fr : n.en;
}

bool categoryFromText(const std::string& text, Category* out) {
  if (categoryFromId(fold(text), out)) return true;
  const std::string key = fold(text);
  for (int i = 0; i <= static_cast<int>(Category::Income); ++i) {
    const CatNames& n = kCats[i];
    if (key == fold(n.ar) || key == fold(n.fr) || key == fold(n.en)) {
      if (out) *out = static_cast<Category>(i);
      return true;
    }
  }
  return false;
}

std::string fill(const std::string& templ,
                 std::initializer_list<std::pair<const char*, std::string>> values) {
  std::string out = templ;
  for (const auto& kv : values) {
    const std::string needle = std::string("{") + kv.first + "}";
    size_t pos = 0;
    while ((pos = out.find(needle, pos)) != std::string::npos) {
      out.replace(pos, needle.size(), kv.second);
      pos += kv.second.size();
    }
  }
  return out;
}

bool isKnownCurrency(const std::string& code) {
  for (const Currency& c : kCurrencies) if (code == c.code) return true;
  return false;
}

std::string currencySymbol(const std::string& code, Lang l) {
  for (const Currency& c : kCurrencies) {
    if (code == c.code) return l == Lang::Ar ? c.ar : c.latin;
  }
  return code;
}

std::string formatAmount(double amount) {
  const bool negative = amount < 0;
  amount = std::fabs(amount);
  char buf[64];
  if (std::fabs(amount - std::round(amount)) < 0.005) std::snprintf(buf, sizeof buf, "%.0f", amount);
  else std::snprintf(buf, sizeof buf, "%.2f", amount);
  std::string s = buf;
  std::string frac;
  const size_t dot = s.find('.');
  if (dot != std::string::npos) {
    frac = s.substr(dot);
    s = s.substr(0, dot);
    while (!frac.empty() && frac.back() == '0') frac.pop_back();
    if (frac == ".") frac.clear();
  }
  std::string grouped;
  for (size_t i = 0; i < s.size(); ++i) {
    if (i > 0 && (s.size() - i) % 3 == 0) grouped.push_back(' ');
    grouped.push_back(s[i]);
  }
  return (negative ? "-" : "") + grouped + frac;
}

}  // namespace masrouf
