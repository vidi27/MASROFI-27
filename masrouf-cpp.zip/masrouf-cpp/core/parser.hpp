// Sentence parser: turns "30 دج ماء" (or "30 ماء و50 خبز", "أمس 200 كراء",
// "+5000 bourse", ...) into expense / income entries. Pure logic, fully offline.
#pragma once
#include <ctime>
#include <string>
#include <vector>

namespace masrouf {

struct ParsedEntry {
  double amount = 0;
  std::string label;   // may be empty ("30" alone, or "استلمت 5000")
  bool income = false;
  std::time_t when = 0;
};

enum class ParseError { None, NoAmount };

struct ParseResult {
  std::vector<ParsedEntry> entries;
  ParseError error = ParseError::None;
  bool dateGiven = false;  // true if the sentence said "أمس", "hier", ...
};

// `now` is the current time (unix seconds); "أمس" / "أول أمس" subtract whole days from it.
ParseResult parseSentence(const std::string& text, std::time_t now);

}  // namespace masrouf
