#include "parser.hpp"

#include <algorithm>
#include <set>

#include "text.hpp"
#include "utf8.hpp"

namespace masrouf {

namespace {

// ---------------------------------------------------------------- characters

bool isDigit(char32_t c) { return c >= U'0' && c <= U'9'; }

bool isSpaceLike(char32_t c) { return c <= 0x20 || c == 0xA0 || c == 0x200F || c == 0x200E; }

// Arabic harakat / tatweel are dropped from labels too.
bool isDiacritic(char32_t c) {
  return (c >= 0x064B && c <= 0x065F) || c == 0x0670 || c == 0x0640;
}

// Step 1: digits, Arabic punctuation, diacritics.
std::u32string mapChars(const std::u32string& in) {
  std::u32string out;
  out.reserve(in.size());
  for (char32_t c : in) {
    if (isDiacritic(c)) continue;
    if (c >= 0x0660 && c <= 0x0669) { out.push_back(U'0' + (c - 0x0660)); continue; }
    if (c >= 0x06F0 && c <= 0x06F9) { out.push_back(U'0' + (c - 0x06F0)); continue; }
    switch (c) {
      case 0x066B: out.push_back(U'.'); break;   // Arabic decimal separator
      case 0x066C: out.push_back(U','); break;   // Arabic thousands separator
      case 0x060C: out.push_back(U','); break;   // Arabic comma
      case 0x061B: case 0x061F: out.push_back(U' '); break;  // Arabic semicolon / question mark
      case 0x2013: case 0x2014: out.push_back(U' '); break;  // dashes
      default: out.push_back(c);
    }
  }
  return out;
}

// Step 2: punctuation -> spaces, "+" and "&" become their own tokens.
std::u32string spacePunctuation(const std::u32string& in) {
  std::u32string out;
  out.reserve(in.size() + 8);
  const size_t n = in.size();
  for (size_t i = 0; i < n; ++i) {
    const char32_t c = in[i];
    const bool digitBefore = i > 0 && isDigit(in[i - 1]);
    const bool digitAfter = i + 1 < n && isDigit(in[i + 1]);
    if (c == U'.' || c == U',') {
      if (digitBefore && digitAfter) out.push_back(c);   // 12.5  1,500
      else if (c == U',') out.push_back(U' ');
      // a lone "." is dropped: "د.ج" -> "دج", "da." -> "da"
      continue;
    }
    if (c == U'+' || c == U'&') {
      out.push_back(U' '); out.push_back(c); out.push_back(U' ');
      continue;
    }
    switch (c) {
      case U'-': case U'_': case U'/': case U'\\': case U':': case U'=': case U';': case U'|':
      case U'(': case U')': case U'[': case U']': case U'{': case U'}': case U'!': case U'?':
      case U'"': case U'*': case U'#': case U'%': case U'~':
        out.push_back(U' ');
        break;
      default:
        out.push_back(c);
    }
  }
  return out;
}

bool isLetterLike(char32_t c) {
  return !isSpaceLike(c) && !isDigit(c) && c != U'.' && c != U',' && c != U'+' && c != U'&';
}

// Step 3: "30دج" -> "30 دج", "ماء30" -> "ماء 30", "و50" -> "و 50".
std::u32string splitGlued(const std::u32string& in) {
  std::u32string out;
  out.reserve(in.size() + 8);
  for (size_t i = 0; i < in.size(); ++i) {
    const char32_t c = in[i];
    if (i > 0) {
      const char32_t p = in[i - 1];
      if ((isDigit(p) && isLetterLike(c)) || (isLetterLike(p) && isDigit(c))) out.push_back(U' ');
    }
    out.push_back(c);
  }
  return out;
}

// ------------------------------------------------------------------- numbers

bool allDigits(const std::string& s) {
  if (s.empty()) return false;
  for (char c : s) if (c < '0' || c > '9') return false;
  return true;
}

// Parses "30", "12.5", "12,5", "1.500", "1,500", "1.500,50".
bool parseNumberUnchecked(const std::string& tok, double* out) {
  std::vector<std::string> groups;
  std::vector<char> seps;
  std::string cur;
  for (char c : tok) {
    if (c == '.' || c == ',') { groups.push_back(cur); cur.clear(); seps.push_back(c); }
    else cur.push_back(c);
  }
  groups.push_back(cur);
  for (const std::string& g : groups) if (!allDigits(g)) return false;

  std::string digits = groups[0];
  if (groups.size() == 1) {
    *out = std::stod(digits);
    return true;
  }

  bool threeDigitGroups = groups[0].size() <= 3 && groups[0] != "0";
  for (size_t i = 1; i < groups.size(); ++i) threeDigitGroups = threeDigitGroups && groups[i].size() == 3;
  const bool sameSeps = std::all_of(seps.begin(), seps.end(), [&](char s) { return s == seps[0]; });

  if (threeDigitGroups && (sameSeps || groups.size() == 2)) {      // 1.500 / 1,500 / 1.500.000
    for (size_t i = 1; i < groups.size(); ++i) digits += groups[i];
    *out = std::stod(digits);
    return true;
  }
  if (sameSeps && groups.size() == 2) {                            // 12.5 / 12,5
    *out = std::stod(groups[0] + "." + groups[1]);
    return true;
  }
  if (!sameSeps) {                                                 // 1.500,50 / 1,500.50
    const std::string decimals = groups.back();
    std::string whole;
    for (size_t i = 0; i + 1 < groups.size(); ++i) whole += groups[i];
    *out = std::stod(whole + "." + decimals);
    return true;
  }
  return false;
}

// Never throws: absurdly long or huge numbers are simply not treated as amounts.
bool parseNumber(const std::string& tok, double* out) {
  try {
    double v = 0;
    if (!parseNumberUnchecked(tok, &v)) return false;
    if (!(v >= 0 && v <= 1e12)) return false;
    *out = v;
    return true;
  } catch (...) {
    return false;
  }
}

// ------------------------------------------------------------------ keywords

std::set<std::string> foldedSet(std::initializer_list<const char*> words) {
  std::set<std::string> s;
  for (const char* w : words) s.insert(stripAl(fold(w)));
  return s;
}

const std::set<std::string>& currencyWords() {
  static const auto s = foldedSet({"دج", "da", "dzd", "dinar", "dinars", "دينار", "دنانير", "dz",
                                   "eur", "euro", "€", "usd", "$", "mad", "dh", "tnd", "sar", "egp",
                                   "ريال"});
  return s;
}

const std::set<std::string>& connectorWords() {
  static const auto s = foldedSet({"و", "et", "and", "&", "w"});
  return s;
}

// Income words that are removed from the label ("استلمت 5000" -> label empty).
const std::set<std::string>& incomeVerbs() {
  static const auto s = foldedSet({"استلمت", "قبضت", "وصلني", "وصلتني", "جاني", "recu", "recue",
                                   "received"});
  return s;
}

// Income words that also describe the entry and stay in the label ("bourse").
const std::set<std::string>& incomeNouns() {
  static const auto s = foldedSet({"مصروف", "مصروفي", "bourse", "راتب", "salaire", "منحة",
                                   "income", "salary", "allowance"});
  return s;
}

struct Token {
  std::string orig;    // text to show in the label
  std::string folded;  // text used for keyword matching
};

// Removes "أمس" / "hier" / ... and returns how many days to go back (0 if none).
int extractDate(std::vector<Token>& tokens, bool* given) {
  static const std::set<std::string> yesterday = foldedSet({"أمس", "البارح", "البارحة", "hier",
                                                           "yesterday"});
  static const std::set<std::string> today = foldedSet({"اليوم", "today"});
  int days = 0;
  *given = false;
  std::vector<Token> kept;
  for (size_t i = 0; i < tokens.size(); ++i) {
    const std::string& f = tokens[i].folded;
    const std::string next = i + 1 < tokens.size() ? tokens[i + 1].folded : std::string();
    if ((f == fold("أول") && yesterday.count(stripAl(next))) || (f == "avant" && next == "hier")) {
      if (!*given) { days = 2; *given = true; }
      ++i;
      continue;
    }
    if (f == "aujourd" && next == "hui") {
      if (!*given) { days = 0; *given = true; }
      ++i;
      continue;
    }
    if (yesterday.count(stripAl(f))) {
      if (!*given) { days = 1; *given = true; }
      continue;
    }
    if (today.count(stripAl(f))) {
      if (!*given) { days = 0; *given = true; }
      continue;
    }
    kept.push_back(tokens[i]);
  }
  tokens.swap(kept);
  return days;
}

// ------------------------------------------------------------------- parsing

struct Item {
  bool isNum = false;
  double value = 0;
  bool plus = false;
  Token tok;
};

bool isConnector(const Item& it) { return !it.isNum && connectorWords().count(it.tok.folded) > 0; }

struct Slot {
  double amount = 0;
  bool plus = false;
  std::vector<Token> words;
};

// Words between two positions of `items` (exclusive), numbers excluded.
std::vector<Token> wordsBetween(const std::vector<Item>& items, int from, int to) {
  std::vector<Token> out;
  for (int i = from; i < to; ++i) if (!items[i].isNum) out.push_back(items[i].tok);
  return out;
}

void trimConnectors(std::vector<Token>& words) {
  auto isConn = [](const Token& t) { return connectorWords().count(t.folded) > 0; };
  while (!words.empty() && isConn(words.front())) words.erase(words.begin());
  while (!words.empty() && isConn(words.back())) words.pop_back();
}

int scoreSlots(const std::vector<Slot>& slots, int totalWords) {
  int empty = 0, used = 0;
  for (const Slot& s : slots) {
    std::vector<Token> w = s.words;
    trimConnectors(w);
    if (w.empty()) ++empty;
    used += static_cast<int>(w.size());
  }
  return empty * 100 + (totalWords - used);  // lower is better
}

}  // namespace

ParseResult parseSentence(const std::string& text, std::time_t now) {
  ParseResult result;

  // 1) normalize characters and split into tokens
  const std::u32string cleaned =
      splitGlued(spacePunctuation(mapChars(decodeUtf8(text))));
  std::vector<Token> tokens;
  for (const std::string& w : splitSpaces(encodeUtf8(cleaned))) tokens.push_back({w, fold(w)});

  // 2) date words
  const int daysBack = extractDate(tokens, &result.dateGiven);

  // 3) numbers, "+" flags, currency words
  std::vector<Item> items;
  bool pendingPlus = false;
  for (const Token& t : tokens) {
    if (t.orig == "+") { pendingPlus = true; continue; }
    if (currencyWords().count(stripAl(t.folded))) continue;
    double value = 0;
    if (!t.folded.empty() && (t.folded[0] >= '0' && t.folded[0] <= '9') && parseNumber(t.folded, &value)) {
      Item it;
      it.isNum = true;
      it.value = value;
      it.plus = pendingPlus;
      pendingPlus = false;
      items.push_back(it);
    } else {
      pendingPlus = false;
      Item it;
      it.tok = t;
      items.push_back(it);
    }
  }

  std::vector<int> nums;
  for (int i = 0; i < static_cast<int>(items.size()); ++i) if (items[i].isNum && items[i].value > 0) nums.push_back(i);
  if (nums.empty()) {
    result.error = ParseError::NoAmount;
    return result;
  }

  // 4) attach the words to each amount
  std::vector<Slot> slots;
  const int itemCount = static_cast<int>(items.size());
  if (nums.size() == 1) {
    Slot s;
    s.amount = items[nums[0]].value;
    s.plus = items[nums[0]].plus;
    s.words = wordsBetween(items, 0, itemCount);
    slots.push_back(s);
  } else {
    int totalWords = 0;
    for (const Item& it : items) if (!it.isNum && !isConnector(it)) ++totalWords;

    std::vector<Slot> amountFirst, labelFirst;
    for (size_t k = 0; k < nums.size(); ++k) {
      Slot a;
      a.amount = items[nums[k]].value;
      a.plus = items[nums[k]].plus;
      a.words = wordsBetween(items, nums[k] + 1, k + 1 < nums.size() ? nums[k + 1] : itemCount);
      amountFirst.push_back(a);

      Slot b;
      b.amount = a.amount;
      b.plus = a.plus;
      b.words = wordsBetween(items, k == 0 ? 0 : nums[k - 1] + 1, nums[k]);
      labelFirst.push_back(b);
    }
    const int sa = scoreSlots(amountFirst, totalWords);
    const int sb = scoreSlots(labelFirst, totalWords);
    const bool startsWithNumber = items.front().isNum;
    const bool useAmountFirst = sa < sb || (sa == sb && startsWithNumber);
    slots = useAmountFirst ? amountFirst : labelFirst;
  }

  // 5) build the entries
  for (Slot& s : slots) {
    trimConnectors(s.words);
    bool income = s.plus;
    std::vector<std::string> labelWords;
    for (const Token& t : s.words) {
      const std::string key = stripAl(t.folded);
      if (incomeVerbs().count(key)) { income = true; continue; }
      if (incomeNouns().count(key)) income = true;
      labelWords.push_back(t.orig);
    }
    ParsedEntry e;
    e.amount = s.amount;
    e.label = joinWords(labelWords);
    e.income = income;
    e.when = now - static_cast<std::time_t>(daysBack) * 86400;
    result.entries.push_back(e);
  }
  return result;
}

}  // namespace masrouf
