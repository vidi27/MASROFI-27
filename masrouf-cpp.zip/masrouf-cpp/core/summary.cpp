#include "summary.hpp"

#include <algorithm>

namespace masrouf {

namespace {

std::tm toLocal(std::time_t t) {
  std::tm out{};
#ifdef _WIN32
  localtime_s(&out, &t);
#else
  localtime_r(&t, &out);
#endif
  return out;
}

std::time_t fromLocal(std::tm tm) {
  tm.tm_isdst = -1;
  return std::mktime(&tm);  // normalizes out-of-range day / month values
}

}  // namespace

Range rangeFor(Period p, std::time_t now, int offset) {
  std::tm tm = toLocal(now);
  tm.tm_hour = tm.tm_min = tm.tm_sec = 0;
  Range r;
  switch (p) {
    case Period::Day: {
      tm.tm_mday += offset;
      r.begin = fromLocal(tm);
      tm.tm_mday += 1;
      r.end = fromLocal(tm);
      break;
    }
    case Period::Week: {
      tm.tm_mday += -tm.tm_wday + offset * 7;  // back to Sunday
      r.begin = fromLocal(tm);
      tm.tm_mday += 7;
      r.end = fromLocal(tm);
      break;
    }
    case Period::Month: {
      tm.tm_mday = 1;
      tm.tm_mon += offset;
      r.begin = fromLocal(tm);
      tm.tm_mon += 1;
      r.end = fromLocal(tm);
      break;
    }
  }
  return r;
}

Summary summarize(const std::vector<Entry>& entries, Range range) {
  Summary s;
  double perCat[8] = {0, 0, 0, 0, 0, 0, 0, 0};
  for (const Entry& e : entries) {
    if (e.when < range.begin || e.when >= range.end) continue;
    ++s.count;
    if (e.income) {
      s.income += e.amount;
    } else {
      s.expenses += e.amount;
      perCat[static_cast<int>(e.category)] += e.amount;
    }
  }
  for (int i = 0; i < 8; ++i) {
    if (perCat[i] <= 0) continue;
    CategoryTotal t;
    t.category = static_cast<Category>(i);
    t.total = perCat[i];
    t.percent = s.expenses > 0 ? perCat[i] * 100.0 / s.expenses : 0;
    s.byCategory.push_back(t);
  }
  std::sort(s.byCategory.begin(), s.byCategory.end(),
            [](const CategoryTotal& a, const CategoryTotal& b) { return a.total > b.total; });
  return s;
}

double monthExpenses(const std::vector<Entry>& entries, std::time_t now) {
  return summarize(entries, rangeFor(Period::Month, now, 0)).expenses;
}

}  // namespace masrouf
