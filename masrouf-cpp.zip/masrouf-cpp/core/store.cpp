#include "store.hpp"

#include <algorithm>
#include <cstdlib>
#include <filesystem>
#include <fstream>
#include <sstream>

namespace fs = std::filesystem;

namespace masrouf {

namespace {

std::string escapeField(const std::string& s) {
  std::string out;
  for (char c : s) {
    if (c == '\\') out += "\\\\";
    else if (c == '\t') out += "\\t";
    else if (c == '\n') out += "\\n";
    else if (c == '\r') out += "\\r";
    else out.push_back(c);
  }
  return out;
}

std::string unescapeField(const std::string& s) {
  std::string out;
  for (size_t i = 0; i < s.size(); ++i) {
    if (s[i] == '\\' && i + 1 < s.size()) {
      const char n = s[++i];
      out.push_back(n == 't' ? '\t' : n == 'n' ? '\n' : n == 'r' ? '\r' : n);
    } else {
      out.push_back(s[i]);
    }
  }
  return out;
}

std::vector<std::string> splitTabs(const std::string& line) {
  std::vector<std::string> out;
  std::string cur;
  for (char c : line) {
    if (c == '\t') { out.push_back(cur); cur.clear(); }
    else cur.push_back(c);
  }
  out.push_back(cur);
  return out;
}

// Writes to a temporary file, then renames: a crash never leaves a half-written file.
void writeAtomic(const fs::path& path, const std::string& content) {
  const fs::path tmp = path.string() + ".tmp";
  {
    std::ofstream f(tmp, std::ios::binary | std::ios::trunc);
    f << content;
  }
  std::error_code ec;
  fs::rename(tmp, path, ec);
  if (ec) {  // e.g. Windows when the target exists
    fs::remove(path, ec);
    fs::rename(tmp, path, ec);
  }
}

}  // namespace

Store::Store(std::string dir) : dir_(std::move(dir)) {}

std::string Store::defaultDir() {
  if (const char* env = std::getenv("MASROUF_HOME")) if (*env) return env;
  const char* home = std::getenv("HOME");
  if (!home || !*home) home = std::getenv("USERPROFILE");
  if (home && *home) return (fs::path(home) / ".masrouf").string();
  return "masrouf_data";
}

bool Store::load() {
  std::error_code ec;
  fs::create_directories(dir_, ec);
  if (ec) return false;

  entries_.clear();
  learned_.clear();
  settings_.clear();
  nextId_ = 1;

  {
    std::ifstream f(fs::path(dir_) / "entries.tsv", std::ios::binary);
    std::string line;
    while (std::getline(f, line)) {
      const auto p = splitTabs(line);
      if (p.size() < 6) continue;
      Entry e;
      try {
        e.id = std::stoi(p[0]);
        e.income = p[1] == "income";
        e.amount = std::stod(p[2]);
        e.when = static_cast<std::time_t>(std::stoll(p[3]));
      } catch (...) {
        continue;
      }
      Category c = Category::Other;
      categoryFromId(p[4], &c);
      e.category = c;
      e.label = unescapeField(p[5]);
      entries_.push_back(e);
      nextId_ = std::max(nextId_, e.id + 1);
    }
  }
  {
    std::ifstream f(fs::path(dir_) / "learned.tsv", std::ios::binary);
    std::string line;
    while (std::getline(f, line)) {
      const auto p = splitTabs(line);
      Category c;
      if (p.size() >= 2 && categoryFromId(p[1], &c)) learned_[unescapeField(p[0])] = c;
    }
  }
  {
    std::ifstream f(fs::path(dir_) / "settings.tsv", std::ios::binary);
    std::string line;
    while (std::getline(f, line)) {
      const auto p = splitTabs(line);
      if (p.size() >= 2) settings_[unescapeField(p[0])] = unescapeField(p[1]);
    }
  }
  return true;
}

const Entry* Store::find(int id) const {
  for (const Entry& e : entries_) if (e.id == id) return &e;
  return nullptr;
}

std::vector<Entry> Store::add(const std::vector<Entry>& newEntries) {
  std::vector<Entry> added;
  for (Entry e : newEntries) {
    e.id = nextId_++;
    entries_.push_back(e);
    added.push_back(e);
  }
  saveEntries();
  return added;
}

bool Store::remove(int id, Entry* removed) {
  const auto it = std::find_if(entries_.begin(), entries_.end(), [&](const Entry& e) { return e.id == id; });
  if (it == entries_.end()) return false;
  if (removed) *removed = *it;
  entries_.erase(it);
  saveEntries();
  return true;
}

bool Store::update(const Entry& e) {
  for (Entry& cur : entries_) {
    if (cur.id == e.id) {
      cur = e;
      saveEntries();
      return true;
    }
  }
  return false;
}

void Store::learn(const std::string& label, Category cat) {
  const std::string key = normalizeLabel(label);
  if (key.empty()) return;
  learned_[key] = cat;
  saveLearned();
}

std::string Store::get(const std::string& key, const std::string& fallback) const {
  const auto it = settings_.find(key);
  return it == settings_.end() ? fallback : it->second;
}

void Store::set(const std::string& key, const std::string& value) {
  settings_[key] = value;
  saveSettings();
}

void Store::saveEntries() const {
  std::ostringstream out;
  out.precision(12);
  for (const Entry& e : entries_) {
    out << e.id << '\t' << (e.income ? "income" : "expense") << '\t' << e.amount << '\t'
        << static_cast<long long>(e.when) << '\t' << categoryId(e.category) << '\t'
        << escapeField(e.label) << '\n';
  }
  writeAtomic(fs::path(dir_) / "entries.tsv", out.str());
}

void Store::saveLearned() const {
  std::ostringstream out;
  for (const auto& kv : learned_) out << escapeField(kv.first) << '\t' << categoryId(kv.second) << '\n';
  writeAtomic(fs::path(dir_) / "learned.tsv", out.str());
}

void Store::saveSettings() const {
  std::ostringstream out;
  for (const auto& kv : settings_) out << escapeField(kv.first) << '\t' << escapeField(kv.second) << '\n';
  writeAtomic(fs::path(dir_) / "settings.tsv", out.str());
}

}  // namespace masrouf
