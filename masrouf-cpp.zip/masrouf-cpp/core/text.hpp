// Text helpers shared by the parser and the categorizer.
#pragma once
#include <string>
#include <vector>

namespace masrouf {

// Normalizes text so Arabic / French / Latin spellings can be compared:
// lower case, no Latin accents, no Arabic diacritics, unified alef / yaa / taa
// marbuta, Arabic-Indic digits -> ASCII digits, apostrophes -> spaces.
std::string fold(const std::string& utf8);

// Removes the Arabic definite article "ال" from a folded token ("الماء" -> "ماء").
std::string stripAl(const std::string& foldedToken);

// Splits on whitespace.
std::vector<std::string> splitSpaces(const std::string& s);

std::string joinWords(const std::vector<std::string>& words, const std::string& sep = " ");

}  // namespace masrouf
