#include "categories.hpp"

#include <unordered_map>
#include <utility>
#include <vector>

#include "text.hpp"

namespace masrouf {

const char* categoryId(Category c) {
  switch (c) {
    case Category::Food: return "food";
    case Category::Transport: return "transport";
    case Category::Study: return "study";
    case Category::Telecom: return "telecom";
    case Category::Entertainment: return "entertainment";
    case Category::Housing: return "housing";
    case Category::Other: return "other";
    case Category::Income: return "income";
  }
  return "other";
}

bool categoryFromId(const std::string& id, Category* out) {
  static const Category all[] = {Category::Food,          Category::Transport, Category::Study,
                                 Category::Telecom,       Category::Entertainment,
                                 Category::Housing,       Category::Other,     Category::Income};
  for (Category c : all) {
    if (id == categoryId(c)) {
      if (out) *out = c;
      return true;
    }
  }
  return false;
}

std::string normalizeLabel(const std::string& label) {
  std::vector<std::string> words;
  for (const std::string& w : splitSpaces(fold(label))) words.push_back(stripAl(w));
  return joinWords(words);
}

namespace {

struct Keyword {
  const char* text;  // written naturally, folded when the table is built
  Category cat;
  int weight;  // 1 = generic word, 2 = specific word, 3 = phrase
};

#define K(text, cat) {text, Category::cat, 2}
#define G(text, cat) {text, Category::cat, 1}
#define P(text, cat) {text, Category::cat, 3}

// Keep every entry unique: a word belongs to exactly one category.
const Keyword kKeywords[] = {
    // ---- Food & drinks (Arabic, Darija, French, English) ----
    K("ماء", Food), K("ميا", Food), K("مياه", Food), K("خبز", Food), K("كسرة", Food),
    K("باقيت", Food), K("baguette", Food), K("pain", Food), K("حليب", Food), K("lait", Food),
    K("قهوة", Food), K("cafe", Food), K("شاي", Food), K("the", Food), K("عصير", Food),
    K("jus", Food), K("اكل", Food), K("أكلة", Food), K("غداء", Food), K("عشاء", Food),
    K("فطور", Food), K("dejeuner", Food), K("diner", Food), K("repas", Food), K("مطعم", Food),
    K("restaurant", Food), K("resto", Food), K("ساندويتش", Food), K("سندويش", Food),
    K("sandwich", Food), K("بيتزا", Food), K("pizza", Food), K("حلوى", Food), K("حلويات", Food),
    K("gateau", Food), K("كعك", Food), K("خضر", Food), K("خضرة", Food), K("فواكه", Food),
    K("فاكهة", Food), K("legumes", Food), K("fruits", Food), K("لحم", Food), K("viande", Food),
    K("دجاج", Food), K("poulet", Food), K("سمك", Food), K("poisson", Food), K("بيض", Food),
    K("oeuf", Food), K("oeufs", Food), K("زيت", Food), K("huile", Food), K("سكر", Food),
    K("sucre", Food), K("ملح", Food), K("soda", Food), K("مشروب", Food), K("boisson", Food),
    K("eau", Food), K("courses", Food), K("سوق", Food), K("marche", Food), K("snack", Food),
    K("croissant", Food), K("كرواسون", Food), K("تمر", Food), K("جبن", Food), K("fromage", Food),
    K("طماطم", Food), K("بطاطا", Food), K("kebab", Food), K("شاورما", Food), K("shawarma", Food),
    K("tacos", Food), K("burger", Food), K("glace", Food), K("قاطو", Food), K("food", Food),
    K("water", Food), K("bread", Food), K("milk", Food), K("coffee", Food), K("tea", Food),
    K("lunch", Food), K("dinner", Food), K("breakfast", Food), K("groceries", Food),
    K("grocery", Food), P("ايس كريم", Food), P("fast food", Food),

    // ---- Transport ----
    K("طرام", Transport), K("tram", Transport), K("طرامواي", Transport), K("tramway", Transport),
    K("حافلة", Transport), K("bus", Transport), K("اتوبيس", Transport), K("طاكسي", Transport),
    K("taxi", Transport), K("تاكسي", Transport), K("مترو", Transport), K("metro", Transport),
    K("قطار", Transport), K("train", Transport), K("بنزين", Transport), K("essence", Transport),
    K("carburant", Transport), K("gasoil", Transport), K("مازوت", Transport), K("وقود", Transport),
    K("تذكرة", Transport), K("ticket", Transport), K("billet", Transport), K("نقل", Transport),
    K("transport", Transport), K("parking", Transport), K("موقف", Transport),
    K("uber", Transport), K("yassir", Transport), K("ياسر", Transport), K("indrive", Transport),
    K("vtc", Transport), K("avion", Transport), K("طيارة", Transport), K("طائرة", Transport),
    K("vol", Transport), K("lavage", Transport), K("vidange", Transport), K("fuel", Transport),
    K("navette", Transport), K("car", Transport),

    // ---- Study & books ----
    K("كتاب", Study), K("livre", Study), K("كتب", Study), K("livres", Study), K("كراس", Study),
    K("كراسة", Study), K("cahier", Study), K("قلم", Study), K("stylo", Study), K("ورق", Study),
    K("papier", Study), K("طباعة", Study), K("impression", Study), K("photocopie", Study),
    K("polycopie", Study), K("poly", Study), K("دراسة", Study), K("etude", Study),
    K("جامعة", Study), K("universite", Study), K("fac", Study), K("inscription", Study),
    K("دورة", Study), K("formation", Study), K("cours", Study), K("دروس", Study), K("درس", Study),
    K("مدرسة", Study), K("ecole", Study), K("calculatrice", Study), K("stage", Study),
    K("امتحان", Study), K("examen", Study), K("مكتبة", Study), K("librairie", Study),
    K("fournitures", Study), K("book", Study), K("books", Study), K("notebook", Study),
    K("pen", Study), K("tuition", Study), K("course", Study), K("exam", Study),
    P("اله حاسبة", Study), P("ادوات مدرسية", Study),

    // ---- Phone & internet ----
    K("انترنت", Telecom), K("internet", Telecom), K("wifi", Telecom),
    K("رصيد", Telecom), K("recharge", Telecom), K("شحن", Telecom), K("تعبئة", Telecom),
    K("flexy", Telecom), K("فليكسي", Telecom), K("idoom", Telecom), K("ايدوم", Telecom),
    K("djezzy", Telecom), K("جازي", Telecom), K("mobilis", Telecom), K("موبيليس", Telecom),
    K("ooredoo", Telecom), K("اوريدو", Telecom), K("forfait", Telecom), K("4g", Telecom),
    K("5g", Telecom), K("data", Telecom), K("adsl", Telecom), P("واي فاي", Telecom),

    // ---- Entertainment ----
    K("سينما", Entertainment), K("cinema", Entertainment), K("فيلم", Entertainment),
    K("film", Entertainment), K("لعبة", Entertainment), K("jeu", Entertainment),
    K("jeux", Entertainment), K("العاب", Entertainment), K("gaming", Entertainment),
    K("netflix", Entertainment), K("نتفليكس", Entertainment), K("spotify", Entertainment),
    K("سبوتيفاي", Entertainment), K("youtube", Entertainment), K("playstation", Entertainment),
    K("ps5", Entertainment), K("ps4", Entertainment), K("sortie", Entertainment),
    K("خروج", Entertainment), K("نزهة", Entertainment), K("حفلة", Entertainment),
    K("fete", Entertainment), K("soiree", Entertainment), K("شيشة", Entertainment),
    K("ملعب", Entertainment), K("stade", Entertainment), K("foot", Entertainment),
    K("رياضة", Entertainment), K("gym", Entertainment), K("sport", Entertainment),
    K("concert", Entertainment), K("حفل", Entertainment), K("مقهى", Entertainment),
    K("balade", Entertainment), K("loisir", Entertainment), K("ترفيه", Entertainment),
    K("movie", Entertainment), K("game", Entertainment), K("party", Entertainment),

    // ---- Housing & bills ----
    K("كراء", Housing), K("loyer", Housing), K("ايجار", Housing), K("اجار", Housing),
    K("كهرباء", Housing), K("electricite", Housing), K("sonelgaz", Housing),
    K("سونلغاز", Housing), K("غاز", Housing), K("gaz", Housing), K("سكن", Housing),
    K("logement", Housing), K("residence", Housing), K("cite", Housing), K("rent", Housing),
    K("electricity", Housing), K("chauffage", Housing), K("تدفئة", Housing), K("seaal", Housing),
    K("syndic", Housing), G("facture", Housing), G("فاتورة", Housing), G("bill", Housing),
    G("bills", Housing), P("فاتورة ماء", Housing), P("facture eau", Housing),
    P("facture d eau", Housing),
};

#undef K
#undef G
#undef P

struct Index {
  std::unordered_map<std::string, std::vector<std::pair<Category, int>>> words;
  std::vector<std::pair<std::string, std::pair<Category, int>>> phrases;  // padded with spaces

  Index() {
    for (const Keyword& k : kKeywords) {
      const std::string key = normalizeLabel(k.text);
      if (key.find(' ') != std::string::npos) {
        phrases.push_back({" " + key + " ", {k.cat, k.weight}});
      } else {
        words[key].push_back({k.cat, k.weight});
      }
    }
  }
};

const Index& index() {
  static const Index idx;
  return idx;
}

}  // namespace

Category categorize(const std::string& label, const LearnedMap& learned) {
  const std::string key = normalizeLabel(label);
  if (key.empty()) return Category::Other;

  const auto it = learned.find(key);
  if (it != learned.end()) return it->second;

  const Index& idx = index();
  int score[8] = {0, 0, 0, 0, 0, 0, 0, 0};

  for (const std::string& w : splitSpaces(key)) {
    const auto f = idx.words.find(w);
    if (f == idx.words.end()) continue;
    for (const auto& entry : f->second) score[static_cast<int>(entry.first)] += entry.second;
  }
  const std::string padded = " " + key + " ";
  for (const auto& p : idx.phrases) {
    if (padded.find(p.first) != std::string::npos) {
      score[static_cast<int>(p.second.first)] += p.second.second;
    }
  }

  int best = -1;
  int bestScore = 0;
  for (int i = 0; i < static_cast<int>(Category::Other); ++i) {  // Other / Income never win
    if (score[i] > bestScore) {
      bestScore = score[i];
      best = i;
    }
  }
  return best < 0 ? Category::Other : static_cast<Category>(best);
}

}  // namespace masrouf
