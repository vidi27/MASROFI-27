// Interface texts in Arabic (default), French and English, plus currencies.
#pragma once
#include <initializer_list>
#include <string>
#include <utility>

#include "categories.hpp"

namespace masrouf {

enum class Lang { Ar, Fr, En };

bool langFromCode(const std::string& code, Lang* out);  // "ar" / "fr" / "en"
const char* langCode(Lang l);
bool isRtl(Lang l);

struct Tr {
  const char* welcome;
  const char* prompt_hint;
  const char* saved_one;        // {amount} {cur} {label}
  const char* saved_income;     // {amount} {cur} {label}
  const char* saved_many;       // {n}
  const char* undo_hint;
  const char* need_amount;
  const char* undone;
  const char* nothing_to_undo;
  const char* deleted;          // {id}
  const char* updated;          // {id}
  const char* not_found;        // {id}
  const char* budget_alert;     // {pct}
  const char* budget_line;      // {spent} {budget} {left}
  const char* budget_over;      // {over} {spent} {budget}
  const char* budget_set;       // {budget}
  const char* budget_off;
  const char* lang_set;
  const char* currency_set;     // {cur}
  const char* currency_unknown;
  const char* category_set;     // {id} {cat}
  const char* category_unknown;
  const char* default_expense;
  const char* default_income;
  const char* empty_list;
  const char* empty_period;
  const char* total_expenses;
  const char* total_income;
  const char* balance;
  const char* period_day;
  const char* period_week;
  const char* period_month;
  const char* unknown_command;
  const char* help;
  const char* usage_edit;
  const char* usage_cat;
  const char* usage_budget;
  const char* data_error;
  const char* bye;
};

const Tr& tr(Lang l);
std::string categoryName(Category c, Lang l);
// Matches a category by id or by its localized name (folded comparison).
bool categoryFromText(const std::string& text, Category* out);

// Replaces {name} placeholders: fill("hi {x}", {{"x", "Sam"}}) -> "hi Sam".
std::string fill(const std::string& templ,
                 std::initializer_list<std::pair<const char*, std::string>> values);

bool isKnownCurrency(const std::string& code);
std::string currencySymbol(const std::string& code, Lang l);

// 1500 -> "1 500", 12.5 -> "12.5"
std::string formatAmount(double amount);

}  // namespace masrouf
