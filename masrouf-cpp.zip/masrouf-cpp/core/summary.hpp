// Day / week / month summaries.
#pragma once
#include <ctime>
#include <vector>

#include "categories.hpp"
#include "store.hpp"

namespace masrouf {

enum class Period { Day, Week, Month };

struct Range {
  std::time_t begin = 0;  // inclusive
  std::time_t end = 0;    // exclusive
};

// The period that contains `now`, moved by `offset` periods (-1 = the previous one).
// Weeks start on Sunday (Algerian working week).
Range rangeFor(Period p, std::time_t now, int offset = 0);

struct CategoryTotal {
  Category category = Category::Other;
  double total = 0;
  double percent = 0;  // share of total expenses, 0..100
};

struct Summary {
  double expenses = 0;
  double income = 0;
  int count = 0;
  std::vector<CategoryTotal> byCategory;  // expenses only, biggest first
};

Summary summarize(const std::vector<Entry>& entries, Range range);

// Total expenses of the calendar month that contains `now`.
double monthExpenses(const std::vector<Entry>& entries, std::time_t now);

}  // namespace masrouf
