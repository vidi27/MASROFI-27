// Local-first storage: plain text files, no server, no account, works offline.
//   entries.tsv   one expense / income per line
//   learned.tsv   category corrections remembered by the app
//   settings.tsv  language, currency, monthly budget
#pragma once
#include <ctime>
#include <map>
#include <string>
#include <vector>

#include "categories.hpp"

namespace masrouf {

struct Entry {
  int id = 0;
  bool income = false;
  double amount = 0;
  std::time_t when = 0;
  Category category = Category::Other;
  std::string label;
};

class Store {
 public:
  // Directory where the files live (created if missing).
  explicit Store(std::string dir);

  // Default directory: $MASROUF_HOME, else ~/.masrouf, else ./masrouf_data
  static std::string defaultDir();

  bool load();  // returns false only if the directory cannot be created

  const std::vector<Entry>& entries() const { return entries_; }
  const Entry* find(int id) const;

  // Adds entries (their `id` is ignored) and returns them with their new ids.
  std::vector<Entry> add(const std::vector<Entry>& newEntries);
  bool remove(int id, Entry* removed = nullptr);
  bool update(const Entry& e);

  // Category corrections.
  const LearnedMap& learned() const { return learned_; }
  void learn(const std::string& label, Category cat);

  // Settings.
  std::string get(const std::string& key, const std::string& fallback = "") const;
  void set(const std::string& key, const std::string& value);

 private:
  void saveEntries() const;
  void saveLearned() const;
  void saveSettings() const;

  std::string dir_;
  std::vector<Entry> entries_;
  LearnedMap learned_;
  std::map<std::string, std::string> settings_;
  int nextId_ = 1;
};

}  // namespace masrouf
