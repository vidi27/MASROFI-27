// Minimal UTF-8 <-> UTF-32 helpers (the whole app works on UTF-8 strings,
// but Arabic / accented text is processed code point by code point).
#pragma once
#include <string>

namespace masrouf {

std::u32string decodeUtf8(const std::string& s);
std::string encodeUtf8(const std::u32string& s);

}  // namespace masrouf
