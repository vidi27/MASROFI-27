#include "text.hpp"

#include "utf8.hpp"

namespace masrouf {

namespace {

bool isSpace(char32_t c) { return c <= 0x20 || c == 0xA0 || c == 0x200F || c == 0x200E; }

// Appends the folded form of one code point to `out`.
void foldChar(char32_t c, std::u32string& out) {
  // Arabic diacritics (harakat), superscript alef, tatweel: dropped.
  if ((c >= 0x064B && c <= 0x065F) || c == 0x0670 || c == 0x0640) return;
  // Arabic-Indic digits -> ASCII.
  if (c >= 0x0660 && c <= 0x0669) { out.push_back(U'0' + (c - 0x0660)); return; }
  if (c >= 0x06F0 && c <= 0x06F9) { out.push_back(U'0' + (c - 0x06F0)); return; }
  switch (c) {
    case 0x0623: case 0x0625: case 0x0622: case 0x0671: out.push_back(0x0627); return;  // alef variants
    case 0x0649: out.push_back(0x064A); return;                                         // alef maqsura -> yaa
    case 0x0629: out.push_back(0x0647); return;                                         // taa marbuta -> haa
    case U'\'': case 0x2019: case U'`': case 0xB4: out.push_back(U' '); return;
    case 0x153: out.push_back(U'o'); out.push_back(U'e'); return;  // oe ligature
    case 0x152: out.push_back(U'o'); out.push_back(U'e'); return;
    case 0xE6: case 0xC6: out.push_back(U'a'); out.push_back(U'e'); return;
    default: break;
  }
  if (c >= U'A' && c <= U'Z') { out.push_back(c - U'A' + U'a'); return; }
  // Latin-1 accented letters (upper and lower case) -> plain ASCII.
  if ((c >= 0xC0 && c <= 0xC5) || (c >= 0xE0 && c <= 0xE5)) { out.push_back(U'a'); return; }
  if (c == 0xC7 || c == 0xE7) { out.push_back(U'c'); return; }
  if ((c >= 0xC8 && c <= 0xCB) || (c >= 0xE8 && c <= 0xEB)) { out.push_back(U'e'); return; }
  if ((c >= 0xCC && c <= 0xCF) || (c >= 0xEC && c <= 0xEF)) { out.push_back(U'i'); return; }
  if (c == 0xD1 || c == 0xF1) { out.push_back(U'n'); return; }
  if ((c >= 0xD2 && c <= 0xD6) || (c >= 0xF2 && c <= 0xF6)) { out.push_back(U'o'); return; }
  if ((c >= 0xD9 && c <= 0xDC) || (c >= 0xF9 && c <= 0xFC)) { out.push_back(U'u'); return; }
  if (c == 0xDD || c == 0xFD || c == 0xFF) { out.push_back(U'y'); return; }
  out.push_back(c);
}

}  // namespace

std::string fold(const std::string& utf8) {
  const std::u32string in = decodeUtf8(utf8);
  std::u32string tmp;
  tmp.reserve(in.size());
  for (char32_t c : in) foldChar(c, tmp);

  // Collapse whitespace and trim.
  std::u32string out;
  bool pendingSpace = false;
  for (char32_t c : tmp) {
    if (isSpace(c)) {
      pendingSpace = !out.empty();
    } else {
      if (pendingSpace) out.push_back(U' ');
      pendingSpace = false;
      out.push_back(c);
    }
  }
  return encodeUtf8(out);
}

std::string stripAl(const std::string& foldedToken) {
  const std::u32string t = decodeUtf8(foldedToken);
  if (t.size() > 3 && t[0] == 0x0627 && t[1] == 0x0644) return encodeUtf8(t.substr(2));
  return foldedToken;
}

std::vector<std::string> splitSpaces(const std::string& s) {
  std::vector<std::string> out;
  std::string cur;
  for (char ch : s) {
    if (ch == ' ' || ch == '\t' || ch == '\n' || ch == '\r') {
      if (!cur.empty()) { out.push_back(cur); cur.clear(); }
    } else {
      cur.push_back(ch);
    }
  }
  if (!cur.empty()) out.push_back(cur);
  return out;
}

std::string joinWords(const std::vector<std::string>& words, const std::string& sep) {
  std::string out;
  for (size_t i = 0; i < words.size(); ++i) {
    if (i) out += sep;
    out += words[i];
  }
  return out;
}

}  // namespace masrouf
