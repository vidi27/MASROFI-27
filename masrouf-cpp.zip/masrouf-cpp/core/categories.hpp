// Automatic categorization from the words of an expense label.
#pragma once
#include <map>
#include <string>

namespace masrouf {

enum class Category {
  Food,
  Transport,
  Study,
  Telecom,
  Entertainment,
  Housing,
  Other,
  Income  // only used for income entries, never returned by categorize()
};

// Stable ids used in storage and in commands ("food", "transport", ...).
const char* categoryId(Category c);
bool categoryFromId(const std::string& id, Category* out);

// Canonical key of a label: folded, each word without "ال", joined by spaces.
// This is the key used to remember user corrections.
std::string normalizeLabel(const std::string& label);

using LearnedMap = std::map<std::string, Category>;

// Keyword-based matching (Arabic / French / Darija / English).
// A correction remembered in `learned` always wins. Unknown words -> Other.
Category categorize(const std::string& label, const LearnedMap& learned);

}  // namespace masrouf
